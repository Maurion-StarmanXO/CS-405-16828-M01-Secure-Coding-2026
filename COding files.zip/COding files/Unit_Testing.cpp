/**
 * @file main.cpp
 * @brief Software Unit Testing Portfolio Piece matching Google Test standard specifications.
 * Course Milestone: Unit Testing
 */

#include <vector>
#include <memory>
#include <cassert>
#include <ctime>
#include <cstdlib>
#include <stdexcept>
#include "gtest/gtest.h"

// Global test environment setup and tear down
class Environment : public ::testing::Environment {
public:
    ~Environment() override {}
    void SetUp() override { srand(time(nullptr)); }
    void TearDown() override {}
};

// Test fixture to manage shared collection data between test runs
class CollectionTest : public ::testing::Test {
protected:
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override {
        // Instantiate a fresh collection before every test execution
        collection.reset(new std::vector<int>);
    }

    void TearDown() override {
        // Clean up allocation states to prevent memory leaks
        collection->clear();
        collection.reset(nullptr);
    }

    // Helper function to fill the container with random integer entries
    void add_entries(int count) {
        assert(count > 0);
        for (auto i = 0; i < count; ++i) {
            collection->push_back(rand() % 100);
        }
    }
};

/* ============================================================================
 * REQUIRED UNIT TESTS
 * ============================================================================ */

// 1. Verify Smart Pointer Initialization State
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull) {
    ASSERT_TRUE(collection != nullptr);
    ASSERT_NE(collection.get(), nullptr);
}

// 2. Verify Initial Container State is Empty
TEST_F(CollectionTest, IsEmptyOnCreate) {
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0UL);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
/*TEST_F(CollectionTest, AlwaysFail) {
    FAIL();
}*/

// 3. Verify Single-Value Ingestion Performance
TEST_F(CollectionTest, CanAddSingleValueToEmptyVector) {
    ASSERT_TRUE(collection->empty());
    add_entries(1);
    EXPECT_FALSE(collection->empty());
    EXPECT_EQ(collection->size(), 1UL);
}

// 4. Verify Multi-Value Ingestion Performance
TEST_F(CollectionTest, CanAddFiveValuesToVector) {
    ASSERT_TRUE(collection->empty());
    add_entries(5);
    EXPECT_FALSE(collection->empty());
    EXPECT_EQ(collection->size(), 5UL);
}

// 5. Verify Max Size Constraints Against Dynamic Sizing
TEST_F(CollectionTest, MaxSizeIsGreaterThanOrEqualToSize) {
    EXPECT_GE(collection->max_size(), collection->size());
    add_entries(1);
    EXPECT_GE(collection->max_size(), collection->size());
    add_entries(4);
    EXPECT_GE(collection->max_size(), collection->size());
    add_entries(5);
    EXPECT_GE(collection->max_size(), collection->size());
}

// 6. Verify Memory Allocation Capacity Bounds
TEST_F(CollectionTest, CapacityIsGreaterThanOrEqualToSize) {
    EXPECT_GE(collection->capacity(), collection->size());
    add_entries(1);
    EXPECT_GE(collection->capacity(), collection->size());
    add_entries(4);
    EXPECT_GE(collection->capacity(), collection->size());
    add_entries(5);
    EXPECT_GE(collection->capacity(), collection->size());
}

// 7. Verify Sizing Expansion via Resize Operation
TEST_F(CollectionTest, ResizeIncreasesCollectionSize) {
    collection->resize(10);
    EXPECT_EQ(collection->size(), 10UL);
}

// 8. Verify Sizing Reduction via Resize Operation
TEST_F(CollectionTest, ResizeDecreasesCollectionSize) {
    add_entries(10);
    collection->resize(5);
    EXPECT_EQ(collection->size(), 5UL);
}

// 9. Verify Sizing Reduction to Clear State via Resize Operation
TEST_F(CollectionTest, ResizeDecreasesCollectionToZero) {
    add_entries(10);
    collection->resize(0);
    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0UL);
}

// 10. Verify Standard Clear Routine Wipes Elements
TEST_F(CollectionTest, ClearErasesCollection) {
    add_entries(10);
    collection->clear();
    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0UL);
}

// 11. Verify Iterator-Bound Erase Routines
TEST_F(CollectionTest, EraseBeginEndErasesCollection) {
    add_entries(10);
    collection->erase(collection->begin(), collection->end());
    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0UL);
}

// 12. Verify Pre-allocation Modifies Capacity without Mutating Size
TEST_F(CollectionTest, ReserveIncreasesCapacityButNotSize) {
    size_t originalSize = collection->size();
    collection->reserve(100);
    EXPECT_GE(collection->capacity(), 100UL);
    EXPECT_EQ(collection->size(), originalSize);
}

// 13. Verify First Element Retrieval Mechanics
TEST_F(CollectionTest, FrontReturnsFirstValue) {
    collection->push_back(42);
    EXPECT_EQ(collection->front(), 42);
}

/* ============================================================================
 * NEGATIVE UNIT TESTS (Fulfilling Course Requirements)
 * ============================================================================ */

// 14. Negative Test 1: Verify system safely throws out_of_range on invalid index tracking
TEST_F(CollectionTest, AtThrowsOutOfRangeForInvalidIndex) {
    add_entries(5);
    // Cast to (void) silences the compiler's [[nodiscard]] security warning
    EXPECT_THROW((void)collection->at(10), std::out_of_range);
}

// 15. Negative Test 2: Verify access constraints on a blank container
TEST_F(CollectionTest, PopBackOnEmptyVectorThrowsException) {
    ASSERT_TRUE(collection->empty());
    // Cast to (void) silences the compiler's [[nodiscard]] security warning
    EXPECT_THROW((void)collection->at(0), std::out_of_range);
}
